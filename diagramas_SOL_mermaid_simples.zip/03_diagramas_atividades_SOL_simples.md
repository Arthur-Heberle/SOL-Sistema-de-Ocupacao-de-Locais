# Diagramas Mermaid simplificados - Projeto S.O.L.

Versão simplificada para impressão em PDF.

Critério: reduzir quantidade de objetos, setas e textos longos; manter apenas os participantes e transições essenciais de cada caso de uso. O estilo segue a referência do documento da outra equipe: diagramas com caixas grandes, poucas mensagens, fluxos lineares e rótulos curtos.

# Diagramas de Atividades simplificados

---

## Figura A1. Diagrama de Atividades do estado `Aguardando autenticação` da classe `LoginPage` para o [UC001]

```mermaid
flowchart TD
    subgraph ACT["act UC001 | LoginPage | Aguardando autenticação"]
        I((Início)) --> A["Exibir formulário"]
        A --> B{"Campos preenchidos?"}
        B -- Sim --> C["Enviar login"]
        B -- Não --> D["Mostrar erro"]
        C --> F((Fim))
        D --> F
    end
```

---

## Figura A2. Diagrama de Atividades do estado `Realizando autenticação` da classe `UsuarioController` para o [UC001]

```mermaid
flowchart TD
    subgraph ACT["act UC001 | UsuarioController | Realizando autenticação"]
        I((Início)) --> A["Receber LoginDTO"]
        A --> B{"Credenciais válidas?"}
        B -- Sim --> C["Gerar token"]
        B -- Não --> D["Retornar erro"]
        C --> F((Fim))
        D --> F
    end
```

---

## Figura A3. Diagrama de Atividades do estado `Preenchendo reserva diária` da classe `ModalReservaComponent` para o [UC002]

```mermaid
flowchart TD
    subgraph ACT["act UC002 | ModalReservaComponent | Preenchendo reserva diária"]
        I((Início)) --> A["Abrir modal"]
        A --> B{"Dados válidos?"}
        B -- Sim --> C["Enviar reserva"]
        B -- Não --> D["Solicitar correção"]
        C --> F((Fim))
        D --> F
    end
```

---

## Figura A4. Diagrama de Atividades do estado `Registrando reserva diária` da classe `ReservaService` para o [UC002]

```mermaid
flowchart TD
    subgraph ACT["act UC002 | ReservaService | Registrando reserva diária"]
        I((Início)) --> A["Receber reserva"]
        A --> B{"Sala livre?"}
        B -- Sim --> C["Salvar aprovada"]
        B -- Não --> D["Retornar conflito"]
        C --> F((Fim))
        D --> F
    end
```

---

## Figura A5. Diagrama de Atividades do estado `Preenchendo reserva semestral` da classe `ModalReservaComponent` para o [UC003]

```mermaid
flowchart TD
    subgraph ACT["act UC003 | ModalReservaComponent | Preenchendo reserva semestral"]
        I((Início)) --> A["Abrir modal"]
        A --> B{"Dados válidos?"}
        B -- Sim --> C["Enviar pedido"]
        B -- Não --> D["Solicitar correção"]
        C --> F((Fim))
        D --> F
    end
```

---

## Figura A6. Diagrama de Atividades do estado `Gerando solicitação pendente` da classe `ReservaService` para o [UC003]

```mermaid
flowchart TD
    subgraph ACT["act UC003 | ReservaService | Gerando solicitação pendente"]
        I((Início)) --> A["Receber pedido"]
        A --> B{"Pode solicitar?"}
        B -- Sim --> C["Salvar pendente"]
        B -- Não --> D["Bloquear pedido"]
        C --> F((Fim))
        D --> F
    end
```

---

## Figura A7. Diagrama de Atividades do estado `Avaliando solicitação` da classe `DashboardPage` para o [UC004]

```mermaid
flowchart TD
    subgraph ACT["act UC004 | DashboardPage | Avaliando solicitação"]
        I((Início)) --> A["Listar pendências"]
        A --> B{"Gestor aprova?"}
        B -- Sim --> C["Enviar aprovação"]
        B -- Não --> D["Enviar rejeição"]
        C --> F((Fim))
        D --> F
    end
```

---

## Figura A8. Diagrama de Atividades do estado `Atualizando status da reserva` da classe `ReservaService` para o [UC004]

```mermaid
flowchart TD
    subgraph ACT["act UC004 | ReservaService | Atualizando status da reserva"]
        I((Início)) --> A["Buscar reserva"]
        A --> B{"Existe conflito?"}
        B -- Sim --> C["Salvar status"]
        B -- Não --> D["Retornar erro"]
        C --> F((Fim))
        D --> F
    end
```

---

## Figura A9. Diagrama de Atividades do estado `Atualizando status do projeto` da classe `ProjetoService` para o [UC004]

```mermaid
flowchart TD
    subgraph ACT["act UC004 | ProjetoService | Atualizando status do projeto"]
        I((Início)) --> A["Buscar projeto"]
        A --> B{"Projeto existe?"}
        B -- Sim --> C["Salvar decisão"]
        B -- Não --> D["Retornar erro"]
        C --> F((Fim))
        D --> F
    end
```

---

## Figura A10. Diagrama de Atividades do estado `Aplicando filtros` da classe `MapaComponent` para o [UC005]

```mermaid
flowchart TD
    subgraph ACT["act UC005 | MapaComponent | Aplicando filtros"]
        I((Início)) --> A["Receber filtros"]
        A --> B{"Há resultados?"}
        B -- Sim --> C["Exibir grade"]
        B -- Não --> D["Mostrar vazio"]
        C --> F((Fim))
        D --> F
    end
```

---

## Figura A11. Diagrama de Atividades do estado `Consultando grade` da classe `SalaService` para o [UC005]

```mermaid
flowchart TD
    subgraph ACT["act UC005 | SalaService | Consultando grade"]
        I((Início)) --> A["Consultar salas"]
        A --> B{"Há reservas?"}
        B -- Sim --> C["Montar grade"]
        B -- Não --> D["Retornar grade vazia"]
        C --> F((Fim))
        D --> F
    end
```

---

## Figura A12. Diagrama de Atividades do estado `Preenchendo cadastro` da classe `FormProjetoComponent` para o [UC006]

```mermaid
flowchart TD
    subgraph ACT["act UC006 | FormProjetoComponent | Preenchendo cadastro"]
        I((Início)) --> A["Abrir formulário"]
        A --> B{"Campos válidos?"}
        B -- Sim --> C["Enviar projeto"]
        B -- Não --> D["Mostrar erro"]
        C --> F((Fim))
        D --> F
    end
```

---

## Figura A13. Diagrama de Atividades do estado `Registrando projeto` da classe `ProjetoService` para o [UC006]

```mermaid
flowchart TD
    subgraph ACT["act UC006 | ProjetoService | Registrando projeto"]
        I((Início)) --> A["Receber projeto"]
        A --> B{"Solicitante autorizado?"}
        B -- Sim --> C["Salvar pendente"]
        B -- Não --> D["Negar cadastro"]
        C --> F((Fim))
        D --> F
    end
```

---

## Figura A14. Diagrama de Atividades do estado `Gerenciando atividade` da classe `ProjetoPage` para o [UC007]

```mermaid
flowchart TD
    subgraph ACT["act UC007 | ProjetoPage | Gerenciando atividade"]
        I((Início)) --> A["Abrir projeto"]
        A --> B{"Projeto aprovado?"}
        B -- Sim --> C["Enviar atividade"]
        B -- Não --> D["Bloquear ação"]
        C --> F((Fim))
        D --> F
    end
```

---

## Figura A15. Diagrama de Atividades do estado `Registrando atividade` da classe `ReservaService` para o [UC007]

```mermaid
flowchart TD
    subgraph ACT["act UC007 | ReservaService | Registrando atividade"]
        I((Início)) --> A["Validar membro"]
        A --> B{"Autorizado?"}
        B -- Sim --> C["Salvar atividade"]
        B -- Não --> D["Negar ação"]
        C --> F((Fim))
        D --> F
    end
```

---

## Figura A16. Diagrama de Atividades do estado `Selecionando horários` da classe `HorariosLivresComponent` para o [UC008]

```mermaid
flowchart TD
    subgraph ACT["act UC008 | HorariosLivresComponent | Selecionando horários"]
        I((Início)) --> A["Exibir grade"]
        A --> B{"Usuário salvou?"}
        B -- Sim --> C["Enviar horários"]
        B -- Não --> D["Continuar edição"]
        C --> F((Fim))
        D --> F
    end
```

---

## Figura A17. Diagrama de Atividades do estado `Calculando interseção` da classe `DisponibilidadeService` para o [UC008]

```mermaid
flowchart TD
    subgraph ACT["act UC008 | DisponibilidadeService | Calculando interseção"]
        I((Início)) --> A["Receber horários"]
        A --> B{"Membro válido?"}
        B -- Sim --> C["Calcular interseção"]
        B -- Não --> D["Retornar erro"]
        C --> F((Fim))
        D --> F
    end
```

---

## Figura A18. Diagrama de Atividades do estado `Gerenciando usuários` da classe `GestaoUsuariosPage` para o [UC009]

```mermaid
flowchart TD
    subgraph ACT["act UC009 | GestaoUsuariosPage | Gerenciando usuários"]
        I((Início)) --> A["Listar usuários"]
        A --> B{"Ação escolhida?"}
        B -- Sim --> C["Enviar operação"]
        B -- Não --> D["Cancelar"]
        C --> F((Fim))
        D --> F
    end
```

---

## Figura A19. Diagrama de Atividades do estado `Mantendo usuários` da classe `UsuarioService` para o [UC009]

```mermaid
flowchart TD
    subgraph ACT["act UC009 | UsuarioService | Mantendo usuários"]
        I((Início)) --> A["Receber operação"]
        A --> B{"Dados válidos?"}
        B -- Sim --> C["Salvar usuário"]
        B -- Não --> D["Retornar erro"]
        C --> F((Fim))
        D --> F
    end
```

---

## Figura A20. Diagrama de Atividades do estado `Gerenciando salas` da classe `GestaoSalasPage` para o [UC010]

```mermaid
flowchart TD
    subgraph ACT["act UC010 | GestaoSalasPage | Gerenciando salas"]
        I((Início)) --> A["Listar salas"]
        A --> B{"Dados completos?"}
        B -- Sim --> C["Enviar sala"]
        B -- Não --> D["Mostrar erro"]
        C --> F((Fim))
        D --> F
    end
```

---

## Figura A21. Diagrama de Atividades do estado `Mantendo salas` da classe `SalaService` para o [UC010]

```mermaid
flowchart TD
    subgraph ACT["act UC010 | SalaService | Mantendo salas"]
        I((Início)) --> A["Receber dados"]
        A --> B{"Sala válida?"}
        B -- Sim --> C["Salvar sala"]
        B -- Não --> D["Retornar erro"]
        C --> F((Fim))
        D --> F
    end
```

---

## Figura A22. Diagrama de Atividades do estado `Gerenciando disciplinas` da classe `GestaoDisciplinasPage` para o [UC011]

```mermaid
flowchart TD
    subgraph ACT["act UC011 | GestaoDisciplinasPage | Gerenciando disciplinas"]
        I((Início)) --> A["Listar disciplinas"]
        A --> B{"Dados completos?"}
        B -- Sim --> C["Enviar disciplina"]
        B -- Não --> D["Mostrar erro"]
        C --> F((Fim))
        D --> F
    end
```

---

## Figura A23. Diagrama de Atividades do estado `Mantendo disciplinas` da classe `DisciplinaService` para o [UC011]

```mermaid
flowchart TD
    subgraph ACT["act UC011 | DisciplinaService | Mantendo disciplinas"]
        I((Início)) --> A["Receber dados"]
        A --> B{"Disciplina válida?"}
        B -- Sim --> C["Salvar disciplina"]
        B -- Não --> D["Retornar erro"]
        C --> F((Fim))
        D --> F
    end
```

---

## Figura A24. Diagrama de Atividades do estado `Gerenciando membros` da classe `ProjetoPage` para o [UC012]

```mermaid
flowchart TD
    subgraph ACT["act UC012 | ProjetoPage | Gerenciando membros"]
        I((Início)) --> A["Listar membros"]
        A --> B{"Ação escolhida?"}
        B -- Sim --> C["Enviar operação"]
        B -- Não --> D["Cancelar"]
        C --> F((Fim))
        D --> F
    end
```

---

## Figura A25. Diagrama de Atividades do estado `Atualizando vínculos` da classe `ProjetoService` para o [UC012]

```mermaid
flowchart TD
    subgraph ACT["act UC012 | ProjetoService | Atualizando vínculos"]
        I((Início)) --> A["Validar admin"]
        A --> B{"Autorizado?"}
        B -- Sim --> C["Salvar vínculo"]
        B -- Não --> D["Negar ação"]
        C --> F((Fim))
        D --> F
    end
```

