# Diagramas Mermaid simplificados - Projeto S.O.L.

Versão simplificada para impressão em PDF.

Critério: reduzir quantidade de objetos, setas e textos longos; manter apenas os participantes e transições essenciais de cada caso de uso. O estilo segue a referência do documento da outra equipe: diagramas com caixas grandes, poucas mensagens, fluxos lineares e rótulos curtos.


## Critérios de simplificação adotados

A partir da análise do documento de referência (`Projeto.pdf`), foram observados os seguintes padrões:

1. **Diagramas de comunicação**
   - Poucos objetos por diagrama.
   - Mensagens numeradas, mas com textos curtos.
   - Um fluxo principal por figura.
   - Evita detalhar assinaturas longas de métodos.

2. **Diagramas de estados**
   - Normalmente 2 a 4 estados principais.
   - Um estado inicial e um ou dois finais.
   - Nomes de estados orientados à ação: “Validando dados”, “Criando item”, “Buscando item”.
   - Poucas ramificações, somente sucesso e falha quando necessário.

3. **Diagramas de atividades**
   - Fluxos curtos, com início, ações principais, uma decisão e fim.
   - Labels legíveis para impressão.
   - Evita texto técnico excessivo dentro das caixas.

## Recomendação para inserir no relatório

- Renderize cada Mermaid como imagem separada.
- Use largura mínima de 13 cm no documento.
- Evite colocar mais de 2 diagramas por página.
- Para diagramas de estados e atividades, prefira 1 diagrama por metade de página.
- Para comunicação, prefira 1 diagrama por página quando houver mais de 5 objetos.

