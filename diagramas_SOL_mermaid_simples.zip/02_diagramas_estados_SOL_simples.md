# Diagramas Mermaid simplificados - Projeto S.O.L.

Versão simplificada para impressão em PDF.

Critério: reduzir quantidade de objetos, setas e textos longos; manter apenas os participantes e transições essenciais de cada caso de uso. O estilo segue a referência do documento da outra equipe: diagramas com caixas grandes, poucas mensagens, fluxos lineares e rótulos curtos.

# Diagramas de Estados simplificados

---

## Figura E1. Diagrama de Estados da classe `LoginPage` para o [UC001]

```mermaid
stateDiagram-v2
    direction TB
    [*] --> A
    state A as "Aguardando dados"
    state B as "Enviando login"
    state C as "Autenticado"
    state D as "Erro de login"
    A --> B : informar credenciais
    B --> C : retorno ok
    B --> D : falha
    C --> [*]
    D --> [*]
```

---

## Figura E2. Diagrama de Estados da classe `UsuarioController` para o [UC001]

```mermaid
stateDiagram-v2
    direction TB
    [*] --> A
    state A as "Recebendo login"
    state B as "Autenticando"
    state C as "Token gerado"
    state D as "Erro"
    A --> B : receber LoginDTO
    B --> C : credenciais válidas
    B --> D : inválido
    C --> [*]
    D --> [*]
```

---

## Figura E3. Diagrama de Estados da classe `ModalReservaComponent` para o [UC002]

```mermaid
stateDiagram-v2
    direction TB
    [*] --> A
    state A as "Fechado"
    state B as "Preenchendo diária"
    state C as "Confirmada"
    state D as "Erro"
    A --> B : abrir modal
    B --> C : reserva ok
    B --> D : falha
    C --> [*]
    D --> [*]
```

---

## Figura E4. Diagrama de Estados da classe `ReservaService` para o [UC002]

```mermaid
stateDiagram-v2
    direction TB
    [*] --> A
    state A as "Recebendo reserva"
    state B as "Validando sala"
    state C as "Aprovada"
    state D as "Conflito"
    A --> B : receber pedido
    B --> C : livre
    B --> D : ocupada
    C --> [*]
    D --> [*]
```

---

## Figura E5. Diagrama de Estados da classe `ModalReservaComponent` para o [UC003]

```mermaid
stateDiagram-v2
    direction TB
    [*] --> A
    state A as "Fechado"
    state B as "Preenchendo semestral"
    state C as "Pendente"
    state D as "Erro"
    A --> B : abrir modal
    B --> C : pedido enviado
    B --> D : falha
    C --> [*]
    D --> [*]
```

---

## Figura E6. Diagrama de Estados da classe `ReservaService` para o [UC003]

```mermaid
stateDiagram-v2
    direction TB
    [*] --> A
    state A as "Recebendo pedido"
    state B as "Verificando semestre"
    state C as "Pendente"
    state D as "Bloqueada"
    A --> B : receber pedido
    B --> C : permitido
    B --> D : conflito
    C --> [*]
    D --> [*]
```

---

## Figura E7. Diagrama de Estados da classe `DashboardPage` para o [UC004]

```mermaid
stateDiagram-v2
    direction TB
    [*] --> A
    state A as "Carregando"
    state B as "Avaliando solicitação"
    state C as "Atualizada"
    state D as "Erro"
    A --> B : listar pendências
    B --> C : decisão salva
    B --> D : falha
    C --> [*]
    D --> [*]
```

---

## Figura E8. Diagrama de Estados da classe `ReservaService` para o [UC004]

```mermaid
stateDiagram-v2
    direction TB
    [*] --> A
    state A as "Aguardando decisão"
    state B as "Atualizando reserva"
    state C as "Status alterado"
    state D as "Erro"
    A --> B : decisão recebida
    B --> C : salvou
    B --> D : falha
    C --> [*]
    D --> [*]
```

---

## Figura E9. Diagrama de Estados da classe `ProjetoService` para o [UC004]

```mermaid
stateDiagram-v2
    direction TB
    [*] --> A
    state A as "Aguardando decisão"
    state B as "Atualizando projeto"
    state C as "Status alterado"
    state D as "Erro"
    A --> B : decisão recebida
    B --> C : salvou
    B --> D : falha
    C --> [*]
    D --> [*]
```

---

## Figura E10. Diagrama de Estados da classe `MapaComponent` para o [UC005]

```mermaid
stateDiagram-v2
    direction TB
    [*] --> A
    state A as "Aguardando filtros"
    state B as "Buscando grade"
    state C as "Grade exibida"
    state D as "Sem resultado"
    A --> B : filtrar
    B --> C : encontrou
    B --> D : vazio
    C --> [*]
    D --> [*]
```

---

## Figura E11. Diagrama de Estados da classe `SalaService` para o [UC005]

```mermaid
stateDiagram-v2
    direction TB
    [*] --> A
    state A as "Recebendo filtros"
    state B as "Consultando ocupação"
    state C as "Grade retornada"
    state D as "Erro"
    A --> B : consulta
    B --> C : sucesso
    B --> D : falha
    C --> [*]
    D --> [*]
```

---

## Figura E12. Diagrama de Estados da classe `FormProjetoComponent` para o [UC006]

```mermaid
stateDiagram-v2
    direction TB
    [*] --> A
    state A as "Formulário aberto"
    state B as "Preenchendo projeto"
    state C as "Enviado"
    state D as "Erro"
    A --> B : informar dados
    B --> C : campos válidos
    B --> D : inválido
    C --> [*]
    D --> [*]
```

---

## Figura E13. Diagrama de Estados da classe `ProjetoService` para o [UC006]

```mermaid
stateDiagram-v2
    direction TB
    [*] --> A
    state A as "Recebendo cadastro"
    state B as "Validando projeto"
    state C as "Pendente"
    state D as "Erro"
    A --> B : cadastro
    B --> C : válido
    B --> D : inválido
    C --> [*]
    D --> [*]
```

---

## Figura E14. Diagrama de Estados da classe `ProjetoPage` para o [UC007]

```mermaid
stateDiagram-v2
    direction TB
    [*] --> A
    state A as "Projeto aberto"
    state B as "Agendando atividade"
    state C as "Painel atualizado"
    state D as "Erro"
    A --> B : nova atividade
    B --> C : salva
    B --> D : falha
    C --> [*]
    D --> [*]
```

---

## Figura E15. Diagrama de Estados da classe `ReservaService` para o [UC007]

```mermaid
stateDiagram-v2
    direction TB
    [*] --> A
    state A as "Recebendo atividade"
    state B as "Validando membro"
    state C as "Atividade salva"
    state D as "Erro"
    A --> B : pedido
    B --> C : autorizado
    B --> D : negado
    C --> [*]
    D --> [*]
```

---

## Figura E16. Diagrama de Estados da classe `HorariosLivresComponent` para o [UC008]

```mermaid
stateDiagram-v2
    direction TB
    [*] --> A
    state A as "Grade aberta"
    state B as "Selecionando horários"
    state C as "Interseção exibida"
    state D as "Erro"
    A --> B : marcar horários
    B --> C : salvo
    B --> D : falha
    C --> [*]
    D --> [*]
```

---

## Figura E17. Diagrama de Estados da classe `DisponibilidadeService` para o [UC008]

```mermaid
stateDiagram-v2
    direction TB
    [*] --> A
    state A as "Recebendo horários"
    state B as "Calculando interseção"
    state C as "Resultado retornado"
    state D as "Erro"
    A --> B : dados recebidos
    B --> C : calculado
    B --> D : falha
    C --> [*]
    D --> [*]
```

---

## Figura E18. Diagrama de Estados da classe `GestaoUsuariosPage` para o [UC009]

```mermaid
stateDiagram-v2
    direction TB
    [*] --> A
    state A as "Lista aberta"
    state B as "Editando usuário"
    state C as "Tabela atualizada"
    state D as "Erro"
    A --> B : ação do gestor
    B --> C : salvo
    B --> D : falha
    C --> [*]
    D --> [*]
```

---

## Figura E19. Diagrama de Estados da classe `UsuarioService` para o [UC009]

```mermaid
stateDiagram-v2
    direction TB
    [*] --> A
    state A as "Recebendo operação"
    state B as "Validando usuário"
    state C as "Usuário salvo"
    state D as "Erro"
    A --> B : operação
    B --> C : válido
    B --> D : inválido
    C --> [*]
    D --> [*]
```

---

## Figura E20. Diagrama de Estados da classe `GestaoSalasPage` para o [UC010]

```mermaid
stateDiagram-v2
    direction TB
    [*] --> A
    state A as "Inventário aberto"
    state B as "Editando sala"
    state C as "Inventário atualizado"
    state D as "Erro"
    A --> B : ação do gestor
    B --> C : salvo
    B --> D : falha
    C --> [*]
    D --> [*]
```

---

## Figura E21. Diagrama de Estados da classe `SalaService` para o [UC010]

```mermaid
stateDiagram-v2
    direction TB
    [*] --> A
    state A as "Recebendo operação"
    state B as "Validando sala"
    state C as "Sala salva"
    state D as "Erro"
    A --> B : operação
    B --> C : válida
    B --> D : inválida
    C --> [*]
    D --> [*]
```

---

## Figura E22. Diagrama de Estados da classe `GestaoDisciplinasPage` para o [UC011]

```mermaid
stateDiagram-v2
    direction TB
    [*] --> A
    state A as "Tabela aberta"
    state B as "Editando disciplina"
    state C as "Tabela atualizada"
    state D as "Erro"
    A --> B : ação do gestor
    B --> C : salvo
    B --> D : falha
    C --> [*]
    D --> [*]
```

---

## Figura E23. Diagrama de Estados da classe `DisciplinaService` para o [UC011]

```mermaid
stateDiagram-v2
    direction TB
    [*] --> A
    state A as "Recebendo operação"
    state B as "Validando disciplina"
    state C as "Disciplina salva"
    state D as "Erro"
    A --> B : operação
    B --> C : válida
    B --> D : inválida
    C --> [*]
    D --> [*]
```

---

## Figura E24. Diagrama de Estados da classe `ProjetoPage` para o [UC012]

```mermaid
stateDiagram-v2
    direction TB
    [*] --> A
    state A as "Membros carregados"
    state B as "Gerenciando membro"
    state C as "Lista atualizada"
    state D as "Erro"
    A --> B : ação do admin
    B --> C : salvo
    B --> D : falha
    C --> [*]
    D --> [*]
```

---

## Figura E25. Diagrama de Estados da classe `ProjetoService` para o [UC012]

```mermaid
stateDiagram-v2
    direction TB
    [*] --> A
    state A as "Recebendo operação"
    state B as "Validando permissão"
    state C as "Vínculo salvo"
    state D as "Erro"
    A --> B : operação
    B --> C : autorizado
    B --> D : negado
    C --> [*]
    D --> [*]
```

