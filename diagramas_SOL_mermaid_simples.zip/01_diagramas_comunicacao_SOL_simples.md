# Diagramas Mermaid simplificados - Projeto S.O.L.

Versão simplificada para impressão em PDF.

Critério: reduzir quantidade de objetos, setas e textos longos; manter apenas os participantes e transições essenciais de cada caso de uso. O estilo segue a referência do documento da outra equipe: diagramas com caixas grandes, poucas mensagens, fluxos lineares e rótulos curtos.

# Diagramas de Comunicação simplificados

---

## Figura C1. Diagrama de Comunicação para o [UC001] Autenticação de Usuário

```mermaid
flowchart LR
    subgraph CD001["cd UC001 | Autenticação"]
        U["Usuário"] -->|"1. informa login"| LP["LoginPage"]
        LP -->|"2. envia credenciais"| AS["AuthService"]
        AS -->|"3. autentica"| UC["UsuarioController"]
        UC -->|"4. consulta usuário"| DB[(Banco)]
        DB -->|"5. retorna dados"| UC
        UC -->|"6. token ou erro"| LP
    end
```

---

## Figura C2. Diagrama de Comunicação para o [UC002] Realizar Reserva de Sala para um Dia

```mermaid
flowchart LR
    subgraph CD002["cd UC002 | Reserva diária"]
        U["Professor/Tutor"] -->|"1. escolhe sala"| M["Mapa/Modal"]
        M -->|"2. envia reserva"| RC["ReservaController"]
        RC -->|"3. valida pedido"| RS["ReservaService"]
        RS -->|"4. verifica sala e horário"| DB[(Banco)]
        RS -->|"5. aprova ou rejeita"| RC
        RC -->|"6. mostra resultado"| M
    end
```

---

## Figura C3. Diagrama de Comunicação para o [UC003] Realizar Reserva Definitiva/Semestral

```mermaid
flowchart LR
    subgraph CD003["cd UC003 | Reserva semestral"]
        P["Professor"] -->|"1. solicita troca"| M["ModalReserva"]
        M -->|"2. envia pedido"| RC["ReservaController"]
        RC -->|"3. cria pendência"| RS["ReservaService"]
        RS -->|"4. salva PENDENTE"| DB[(Banco)]
        RS -->|"5. notifica"| D["Dashboard"]
        D -->|"6. exibe ao gestor"| G["Gestor"]
    end
```

---

## Figura C4. Diagrama de Comunicação para o [UC004] Aprovar Solicitações do Sistema

```mermaid
flowchart LR
    subgraph CD004["cd UC004 | Aprovação"]
        G["Gestor"] -->|"1. abre pendências"| D["Dashboard"]
        D -->|"2. envia decisão"| C["Controller"]
        C -->|"3. atualiza status"| S["Service"]
        S -->|"4. salva decisão"| DB[(Banco)]
        S -->|"5. resultado"| C
        C -->|"6. atualiza tela"| D
    end
```

---

## Figura C5. Diagrama de Comunicação para o [UC005] Visualizar Grade de Horários

```mermaid
flowchart LR
    subgraph CD005["cd UC005 | Grade de horários"]
        U["Usuário"] -->|"1. aplica filtros"| M["MapaPage"]
        M -->|"2. busca grade"| SC["SalaController"]
        SC -->|"3. consulta ocupações"| SS["SalaService"]
        SS -->|"4. lê salas/reservas"| DB[(Banco)]
        SS -->|"5. retorna grade"| M
        M -->|"6. exibe calendário"| U
    end
```

---

## Figura C6. Diagrama de Comunicação para o [UC006] Registrar Projeto

```mermaid
flowchart LR
    subgraph CD006["cd UC006 | Registrar projeto"]
        U["Professor/Gestor"] -->|"1. preenche projeto"| F["FormProjeto"]
        F -->|"2. envia cadastro"| PC["ProjetoController"]
        PC -->|"3. valida dados"| PS["ProjetoService"]
        PS -->|"4. salva pendente"| DB[(Banco)]
        PS -->|"5. notifica gestor"| D["Dashboard"]
        F -->|"6. informa status"| U
    end
```

---

## Figura C7. Diagrama de Comunicação para o [UC007] Gerenciar Sala e Atividades de Projeto

```mermaid
flowchart LR
    subgraph CD007["cd UC007 | Atividade de projeto"]
        I["Integrante"] -->|"1. agenda atividade"| PP["ProjetoPage"]
        PP -->|"2. envia atividade"| RC["ReservaController"]
        RC -->|"3. valida membro"| RS["ReservaService"]
        RS -->|"4. salva atividade"| DB[(Banco)]
        RS -->|"5. retorna agenda"| PP
        PP -->|"6. exibe programação"| I
    end
```

---

## Figura C8. Diagrama de Comunicação para o [UC008] Gerenciar Horários Livres dos Integrantes

```mermaid
flowchart LR
    subgraph CD008["cd UC008 | Horários livres"]
        I["Integrante"] -->|"1. marca horários"| H["HorariosLivres"]
        H -->|"2. envia disponibilidade"| DC["DisponibilidadeController"]
        DC -->|"3. calcula interseção"| DS["DisponibilidadeService"]
        DS -->|"4. salva/consulta"| DB[(Banco)]
        DS -->|"5. retorna horários comuns"| H
        H -->|"6. exibe resultado"| I
    end
```

---

## Figura C9. Diagrama de Comunicação para o [UC009] Manter Usuários

```mermaid
flowchart LR
    subgraph CD009["cd UC009 | Manter usuários"]
        G["Gestor"] -->|"1. gerencia usuários"| P["GestaoUsuariosPage"]
        P -->|"2. envia operação"| C["UsuarioController"]
        C -->|"3. valida"| S["UsuarioService"]
        S -->|"4. salva alteração"| DB[(Banco)]
        S -->|"5. retorna lista"| P
        P -->|"6. atualiza tela"| G
    end
```

---

## Figura C10. Diagrama de Comunicação para o [UC010] Manter Salas

```mermaid
flowchart LR
    subgraph CD010["cd UC010 | Manter salas"]
        G["Gestor"] -->|"1. edita sala"| P["GestaoSalasPage"]
        P -->|"2. envia dados"| C["SalaController"]
        C -->|"3. valida sala"| S["SalaService"]
        S -->|"4. salva alteração"| DB[(Banco)]
        S -->|"5. retorna inventário"| P
        P -->|"6. exibe salas"| G
    end
```

---

## Figura C11. Diagrama de Comunicação para o [UC011] Manter Disciplinas

```mermaid
flowchart LR
    subgraph CD011["cd UC011 | Manter disciplinas"]
        G["Gestor"] -->|"1. edita disciplina"| P["GestaoDisciplinasPage"]
        P -->|"2. envia dados"| C["DisciplinaController"]
        C -->|"3. valida disciplina"| S["DisciplinaService"]
        S -->|"4. salva alteração"| DB[(Banco)]
        S -->|"5. retorna tabela"| P
        P -->|"6. exibe disciplinas"| G
    end
```

---

## Figura C12. Diagrama de Comunicação para o [UC012] Gerenciar Membros do Projeto

```mermaid
flowchart LR
    subgraph CD012["cd UC012 | Membros do projeto"]
        A["Admin do Projeto"] -->|"1. altera membro"| PP["ProjetoPage"]
        PP -->|"2. envia operação"| PC["ProjetoController"]
        PC -->|"3. valida permissão"| PS["ProjetoService"]
        PS -->|"4. atualiza vínculo"| DB[(Banco)]
        PS -->|"5. retorna membros"| PP
        PP -->|"6. exibe lista"| A
    end
```

